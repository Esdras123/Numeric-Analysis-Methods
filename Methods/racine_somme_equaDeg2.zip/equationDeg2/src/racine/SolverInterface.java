/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package racine;

/**
 *
 * @author ESDRAS
 */
public interface SolverInterface {
    /*renvoie racine(x) si x est supérieur ou egal a 0
    et null sinon
    */
    Double resolve(double x);
}
