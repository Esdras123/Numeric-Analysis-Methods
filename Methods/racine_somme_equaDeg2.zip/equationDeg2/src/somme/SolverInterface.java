package somme;

public interface SolverInterface {

    Double resolve(double x, double y);
}
