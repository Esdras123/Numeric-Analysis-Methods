package deg1;

public class Resultat {
    double[] a;
    double[] b;
    double[] c;

    public Resultat(double[] a, double[] b, double[] c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
