package deg1;

import org.ujmp.core.DenseMatrix;
import org.ujmp.core.Matrix;
import org.ujmp.core.SparseMatrix;

public class GaussSeidel {

   public  SparseMatrix A;
   public  Matrix b;
   public static Boolean converge= false;

    public GaussSeidel(SparseMatrix A, Matrix b) {
        if (A == null || b == null) {
            throw new NullPointerException();
        }
        if (A.getRowCount() != b.getRowCount()) {
            throw new IllegalArgumentException();
        }
        this.A = A;
        this.b = b;
    }

    public boolean converges() {
        for (int i = 0; i < A.getRowCount(); i++) {
            double diagonal = Math.abs(A.getAsDouble(i, i));
            double tmpSum = 0;
            for (int j = 0; j < A.getRowCount(); j++) {
                if (i != j) {
                    tmpSum += Math.abs(A.getAsDouble(i, j));
                }
            }
            if (tmpSum > diagonal) {
                return false;
            }
        }
        return true;
    }

    public Matrix solveSystem(int precision) {
        /*
        if (!converges()) {
            System.err.println("Non convergence");
        }
        */
    	Matrix x = DenseMatrix.Factory.zeros(this.A.getRowCount(), 1);
	     
		 Matrix x1 = DenseMatrix.Factory.zeros(this.A.getRowCount(), 1);
	      double a=0;
	       do {
	    	 x1=  DenseMatrix.Factory.copyFromMatrix(x);
	        	for (int i = 0; i < this.A.getRowCount(); i++) {
					double x0 = 0;
					
					if(i==0) {
						x0 =this.A.getAsDouble(i,i+1)*x.getAsDouble(i+1,0);
					}
					else if(i==this.A.getRowCount()-1) {
						x0 =this.A.getAsDouble(i,i-1)*x.getAsDouble(i-1,0);
					}else {
						x0 =this.A.getAsDouble(i,i-1)*x.getAsDouble(i-1,0)+this.A.getAsDouble(i,i+1)*x.getAsDouble(i+1,0);
					}
					
					x.setAsDouble(((this.b.getAsDouble(i,0) - x0)/this.A.getAsDouble(i,i)), i, 0);
				        
				
				}
	        	
	        	
	        } while(!GaussSeidel.norme2(x, x1));
        /*
        for (int k = 0; k < precision; k++) {
			for (int i = 0; i < A.getRowCount(); i++) {
				double x0 = 0;
				
				if(i==0) {
					x0 =A.getAsDouble(i,i+1)*x.getAsDouble(i+1,0);
				}
				else if(i==A.getRowCount()-1) {
					x0 =A.getAsDouble(i,i-1)*x.getAsDouble(i-1,0);
				}else {
					x0 =A.getAsDouble(i,i-1)*x.getAsDouble(i-1,0)+A.getAsDouble(i,i+1)*x.getAsDouble(i+1,0);
				}
				
				x.setAsDouble(((b.getAsDouble(i,0) - x0)/A.getAsDouble(i,i)), i, 0);
			        
			
			}
        }*/
        return x;
    }
    public static double norme( Matrix x,  Matrix x2) {
		double val =0.0;
		for (int i = 0; i < x.getRowCount(); i++) {
			
			val+=Math.pow((x.getAsDouble(i,0)-x2.getAsDouble(i,0)),2);
		}
		return Math.pow(val, 0.5);
	}
    
    public static Boolean norme2(Matrix x, Matrix x2) {
    	Boolean converge=true;
    	for (int i = 0; i < x.getRowCount(); i++) {
			
    		if(Math.abs(x.getAsDouble(i,0)-x2.getAsDouble(i,0))>=10e-50){
    			converge = false;
    		}
    	
		}
    	return converge;
    }

}
